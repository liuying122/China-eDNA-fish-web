from django.apps import AppConfig


class 鱼类环境Dna数据库Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = '鱼类环境DNA数据库'
