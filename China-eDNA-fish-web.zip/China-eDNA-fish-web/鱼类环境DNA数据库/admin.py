from django.contrib import admin
from .models import all_12S_info

admin.site.register(all_12S_info)