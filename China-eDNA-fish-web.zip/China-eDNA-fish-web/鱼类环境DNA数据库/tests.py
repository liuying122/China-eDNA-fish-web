# 作者：刘英 (12261077991@qq.com)
# 创建日期：
# 版本：1.0.0
# 描述：
from django.test import TestCase

# Create your tests here.
